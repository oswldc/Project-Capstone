package com.dicoding.gencara.data

data class Menu(
    val icon: Int,
    val menu: String,
)